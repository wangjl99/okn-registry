# Converting RDAccelerate to RDF for FRINK OKN

Complete guide to convert your Neo4j knowledge graph to RDF and query with SPARQL for integration with the FRINK Open Knowledge Network.

---

## 📋 **Prerequisites**

```bash
# Install Python dependencies
pip install neo4j rdflib tqdm

# Make sure Neo4j is running
docker ps | grep rdaccelerate-neo4j
```

---

## 🔄 **Step 1: Export Neo4j to RDF**

```bash
cd ~/Downloads/neo4j_export

# Run the conversion script
python3 export_to_rdf.py
```

**Output:**
```
✓ Connected to Neo4j
Exporting nodes...
Total nodes: 72,368
Nodes: 100%|████████████| 73/73 [00:15<00:00]

Exporting relationships...
Total relationships: 985,616
Edges: 100%|████████████| 986/986 [03:24<00:00]

✓ RDF export complete!
  Triples: 2,115,968
  Turtle: rdaccelerate_kg.ttl
  N-Triples: rdaccelerate_kg.nt
```

**Files created:**
- `rdaccelerate_kg.ttl` - Turtle format (human-readable, ~350MB)
- `rdaccelerate_kg.nt` - N-Triples format (line-based, ~420MB)

---

## 📊 **RDF Data Structure**

### **Namespaces Used**

```turtle
@prefix biolink: <https://w3id.org/biolink/vocab/> .
@prefix rdaccel: <https://rdaccelerate.org/resource/> .
@prefix ordo: <http://www.orpha.net/ORDO/Orphanet_> .
@prefix mondo: <http://purl.obolibrary.org/obo/MONDO_> .
@prefix hp: <http://purl.obolibrary.org/obo/HP_> .
@prefix ncbigene: <http://identifiers.org/ncbigene/> .
@prefix drugbank: <http://identifiers.org/drugbank/> .
@prefix clinvar: <http://www.ncbi.nlm.nih.gov/clinvar/variation/> .
```

### **Sample Triples**

```turtle
# Disease node
ordo:558 a biolink:Disease ;
    rdfs:label "Duchenne muscular dystrophy" ;
    skos:prefLabel "Duchenne muscular dystrophy" ;
    biolink:id "ORDO:558" ;
    biolink:category "biolink:Disease" .

# Phenotype association
ordo:558 biolink:has_phenotype hp:0003560 .

# Phenotype node
hp:0003560 a biolink:PhenotypicFeature ;
    rdfs:label "Muscular dystrophy" ;
    biolink:id "HP:0003560" .

# Drug treatment
drugbank:DB00177 a biolink:Drug ;
    rdfs:label "Valsartan" ;
    biolink:treats ordo:558 .
```

---

## 🐳 **Step 2: Choose Your Triple Store**

### **Option A: Apache Jena Fuseki** (Recommended - Easy to Use)

```bash
# Start Fuseki
docker-compose -f docker-compose-fuseki.yml up -d

# Wait for startup
sleep 10

# Access UI: http://localhost:3030
# Login: admin / rdaccelerate2024
```

**Load data:**
```bash
# Create dataset via UI or command line
curl -X POST http://localhost:3030/$/datasets \
  --user admin:rdaccelerate2024 \
  -H "Content-Type: application/x-www-form-urlencoded" \
  --data "dbName=rdaccelerate&dbType=tdb2"

# Upload RDF data
curl -X POST http://localhost:3030/rdaccelerate/data \
  --user admin:rdaccelerate2024 \
  --data-binary @rdaccelerate_kg.ttl \
  -H "Content-Type: text/turtle"
```

**SPARQL Endpoint:** http://localhost:3030/rdaccelerate/sparql

---

### **Option B: Virtuoso** (High Performance)

```bash
# Start Virtuoso
docker-compose -f docker-compose-virtuoso.yml up -d

# Wait for startup (takes ~30 seconds)
sleep 30

# Access Conductor UI: http://localhost:8890/conductor
# Login: dba / rdaccelerate2024
```

**Load data:**
```bash
# Copy RDF file to container
docker cp rdaccelerate_kg.ttl rdaccelerate-virtuoso:/staging/

# Load into Virtuoso via ISQL
docker exec -it rdaccelerate-virtuoso isql 1111 dba rdaccelerate2024 << 'EOF'
DB.DBA.RDF_LOAD_RDFXML_MT(
  file_to_string_output('/staging/rdaccelerate_kg.ttl'),
  '',
  'http://rdaccelerate.org/knowledge-graph'
);
checkpoint;
EOF
```

**SPARQL Endpoint:** http://localhost:8890/sparql

---

### **Option C: GraphDB** (Enterprise Features)

```bash
# Download GraphDB Free from: https://www.ontotext.com/products/graphdb/download/
# Or use Docker image (requires registration)

docker run -d --name graphdb \
  -p 7200:7200 \
  -v $(pwd)/graphdb_data:/opt/graphdb/home \
  ontotext/graphdb:10.7.0

# Access UI: http://localhost:7200
```

**Load data via UI:**
1. Create repository "rdaccelerate"
2. Go to Import → Upload RDF files
3. Select `rdaccelerate_kg.ttl`
4. Import

**SPARQL Endpoint:** http://localhost:7200/repositories/rdaccelerate

---

## 🔍 **Step 3: Query with SPARQL**

### **Test Connection**

```bash
# Fuseki
curl -X POST http://localhost:3030/rdaccelerate/sparql \
  --data-urlencode "query=SELECT * WHERE { ?s ?p ?o } LIMIT 10"

# Virtuoso
curl -X POST http://localhost:8890/sparql \
  --data-urlencode "query=SELECT * WHERE { ?s ?p ?o } LIMIT 10" \
  --data-urlencode "default-graph-uri=http://rdaccelerate.org/knowledge-graph"
```

---

## 📝 **SPARQL Query Examples**

### **1. Count Entities by Type**

```sparql
PREFIX biolink: <https://w3id.org/biolink/vocab/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?type (COUNT(?entity) AS ?count)
WHERE {
  ?entity a ?type .
  FILTER(STRSTARTS(STR(?type), "https://w3id.org/biolink/vocab/"))
}
GROUP BY ?type
ORDER BY DESC(?count)
```

### **2. Diseases with Phenotypes**

```sparql
PREFIX biolink: <https://w3id.org/biolink/vocab/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?disease_name (COUNT(?phenotype) AS ?phenotype_count)
WHERE {
  ?disease a biolink:Disease ;
           rdfs:label ?disease_name ;
           biolink:has_phenotype ?phenotype .
}
GROUP BY ?disease_name
ORDER BY DESC(?phenotype_count)
LIMIT 20
```

### **3. Find Diseases by Phenotype**

```sparql
PREFIX biolink: <https://w3id.org/biolink/vocab/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?disease_name ?disease_id
WHERE {
  ?disease a biolink:Disease ;
           rdfs:label ?disease_name ;
           biolink:id ?disease_id ;
           biolink:has_phenotype ?phenotype .
  
  ?phenotype rdfs:label ?phenotype_name .
  
  FILTER(CONTAINS(LCASE(?phenotype_name), "muscular dystrophy"))
}
LIMIT 20
```

### **4. Drug Treatments**

```sparql
PREFIX biolink: <https://w3id.org/biolink/vocab/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?drug_name ?disease_name
WHERE {
  ?drug a biolink:Drug ;
        rdfs:label ?drug_name ;
        biolink:treats ?disease .
  
  ?disease a biolink:Disease ;
           rdfs:label ?disease_name .
  
  FILTER(CONTAINS(LCASE(?disease_name), "dystrophy"))
}
LIMIT 20
```

### **5. Gene-Variant-Disease Pathway**

```sparql
PREFIX biolink: <https://w3id.org/biolink/vocab/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?gene_name ?variant_id ?disease_name
WHERE {
  ?variant a biolink:SequenceVariant ;
           biolink:id ?variant_id ;
           biolink:has_gene ?gene ;
           biolink:causes_condition ?disease .
  
  ?gene rdfs:label ?gene_name .
  ?disease a biolink:Disease ;
           rdfs:label ?disease_name .
}
LIMIT 20
```

### **6. Disease Hierarchy**

```sparql
PREFIX biolink: <https://w3id.org/biolink/vocab/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?child_name ?parent_name
WHERE {
  ?child a biolink:Disease ;
         rdfs:label ?child_name ;
         biolink:subclass_of+ ?parent .
  
  ?parent rdfs:label ?parent_name .
  
  FILTER(CONTAINS(LCASE(?child_name), "syndrome"))
}
LIMIT 20
```

### **7. Phenotype Co-occurrence**

```sparql
PREFIX biolink: <https://w3id.org/biolink/vocab/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?p1_name ?p2_name (COUNT(?disease) AS ?co_occurrence)
WHERE {
  ?disease a biolink:Disease ;
           biolink:has_phenotype ?p1, ?p2 .
  
  ?p1 rdfs:label ?p1_name .
  ?p2 rdfs:label ?p2_name .
  
  FILTER(?p1 != ?p2 && STR(?p1) < STR(?p2))
}
GROUP BY ?p1_name ?p2_name
HAVING (COUNT(?disease) > 10)
ORDER BY DESC(?co_occurrence)
LIMIT 20
```

### **8. Drug Repurposing Candidates**

```sparql
PREFIX biolink: <https://w3id.org/biolink/vocab/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?drug_name ?known_disease ?candidate_disease (COUNT(?shared_phenotype) AS ?shared)
WHERE {
  ?drug biolink:treats ?d1 .
  
  ?d1 rdfs:label ?known_disease ;
      biolink:has_phenotype ?phenotype .
  
  ?d2 rdfs:label ?candidate_disease ;
      biolink:has_phenotype ?phenotype .
  
  ?drug rdfs:label ?drug_name .
  
  FILTER(?d1 != ?d2)
  FILTER NOT EXISTS { ?drug biolink:treats ?d2 }
}
GROUP BY ?drug_name ?known_disease ?candidate_disease
HAVING (COUNT(?shared_phenotype) > 5)
ORDER BY DESC(?shared)
LIMIT 20
```

### **9. Find All Paths Between Entities**

```sparql
PREFIX biolink: <https://w3id.org/biolink/vocab/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX ordo: <http://www.orpha.net/ORDO/Orphanet_>

SELECT ?intermediate ?property
WHERE {
  ordo:558 ?p1 ?intermediate .
  ?intermediate ?p2 ?gene .
  
  ?gene a biolink:Gene ;
        rdfs:label "DMD" .
  
  BIND(?p1 AS ?property)
}
LIMIT 10
```

### **10. Federated Query (Cross-Repository)**

```sparql
PREFIX biolink: <https://w3id.org/biolink/vocab/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?disease_name ?external_info
WHERE {
  # Local knowledge graph
  ?disease a biolink:Disease ;
           rdfs:label ?disease_name ;
           biolink:id ?disease_id .
  
  FILTER(CONTAINS(?disease_name, "dystrophy"))
  
  # Query external SPARQL endpoint
  SERVICE <http://sparql.wikipathways.org/sparql> {
    ?pathway rdfs:label ?external_info .
    FILTER(CONTAINS(?external_info, "muscular"))
  }
}
LIMIT 10
```

---

## 🔗 **Integration with FRINK OKN**

### **Register Your SPARQL Endpoint**

1. **Contact FRINK:** https://github.com/frink-okn
2. **Provide endpoint URL:** `http://your-server:3030/rdaccelerate/sparql`
3. **Metadata:**
   ```json
   {
     "name": "RDAccelerate Rare Disease Knowledge Graph",
     "description": "72,368 entities with 985,616 relationships",
     "endpoint": "http://your-server:3030/rdaccelerate/sparql",
     "ontologies": ["Biolink", "Orphanet", "MONDO", "HPO"],
     "license": "MIT",
     "contact": "your-email@uthealth.edu"
   }
   ```

### **VoID Description**

Create `void.ttl`:

```turtle
@prefix void: <http://rdfs.org/ns/void#> .
@prefix dcterms: <http://purl.org/dc/terms/> .
@prefix foaf: <http://xmlns.com/foaf/0.1/> .

<http://rdaccelerate.org/knowledge-graph> a void:Dataset ;
    dcterms:title "RDAccelerate Rare Disease Knowledge Graph" ;
    dcterms:description "Comprehensive rare disease knowledge graph" ;
    dcterms:creator [
        a foaf:Organization ;
        foaf:name "UTHealth Houston"
    ] ;
    dcterms:license <https://opensource.org/licenses/MIT> ;
    void:sparqlEndpoint <http://your-server:3030/rdaccelerate/sparql> ;
    void:triples 2115968 ;
    void:entities 72368 ;
    void:vocabulary <https://w3id.org/biolink/vocab/> .
```

---

## 📊 **Performance Optimization**

### **Virtuoso Indexing**

```sql
-- Connect to ISQL
docker exec -it rdaccelerate-virtuoso isql 1111 dba rdaccelerate2024

-- Create full-text index
DB.DBA.RDF_OBJ_FT_RULE_ADD (null, null, 'All');
DB.DBA.VT_INC_INDEX_DB_DBA_RDF_OBJ ();

-- Update statistics
rdf_graph_stats('http://rdaccelerate.org/knowledge-graph');
```

### **Fuseki Configuration**

Create `fuseki-config.ttl`:

```turtle
@prefix :      <#> .
@prefix fuseki: <http://jena.apache.org/fuseki#> .
@prefix rdf:   <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs:  <http://www.w3.org/2000/01/rdf-schema#> .
@prefix tdb2:  <http://jena.apache.org/2016/tdb#> .
@prefix ja:    <http://jena.hpl.hp.com/2005/11/Assembler#> .

:service rdf:type fuseki:Service ;
    fuseki:name "rdaccelerate" ;
    fuseki:serviceQuery "sparql" ;
    fuseki:serviceUpdate "update" ;
    fuseki:serviceUpload "upload" ;
    fuseki:dataset :dataset .

:dataset rdf:type ja:RDFDataset ;
    ja:defaultGraph :graph .

:graph rdf:type tdb2:GraphTDB ;
    tdb2:location "/fuseki/databases/rdaccelerate" .
```

---

## ✅ **Verification Checklist**

```bash
# 1. Check triple count
curl -X POST http://localhost:3030/rdaccelerate/sparql \
  --data-urlencode "query=SELECT (COUNT(*) AS ?count) WHERE { ?s ?p ?o }"

# Expected: ~2,115,968 triples

# 2. Check entity types
curl -X POST http://localhost:3030/rdaccelerate/sparql \
  --data-urlencode "query=SELECT DISTINCT ?type WHERE { ?s a ?type } ORDER BY ?type"

# 3. Sample query
curl -X POST http://localhost:3030/rdaccelerate/sparql \
  --data-urlencode "query=PREFIX biolink: <https://w3id.org/biolink/vocab/> SELECT * WHERE { ?s a biolink:Disease } LIMIT 5"
```

---

## 🚀 **Next Steps**

1. ✅ Export Neo4j to RDF
2. ✅ Load into triple store
3. ✅ Test SPARQL queries
4. ✅ Register with FRINK OKN
5. 📤 Deploy publicly accessible endpoint
6. 📄 Document API for researchers

---

**Your knowledge graph is now RDF/SPARQL ready for FRINK OKN!** 🎉
