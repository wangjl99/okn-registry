#!/bin/bash
# Automated RDF Conversion and Loading Script
# For RDAccelerate Knowledge Graph → FRINK OKN

set -e

echo "======================================================================"
echo "RDAccelerate → RDF Conversion for FRINK OKN"
echo "======================================================================"
echo ""

# Configuration
TRIPLE_STORE=${1:-fuseki}  # Default to Fuseki

echo "Selected triple store: $TRIPLE_STORE"
echo ""

# Step 1: Export Neo4j to RDF
echo "======================================================================"
echo "Step 1: Exporting Neo4j to RDF"
echo "======================================================================"
echo ""

if [ ! -f "rdaccelerate_kg.ttl" ]; then
    echo "Running export script..."
    python3 export_to_rdf.py
    
    if [ $? -ne 0 ]; then
        echo "✗ Export failed!"
        exit 1
    fi
else
    echo "✓ RDF file already exists (rdaccelerate_kg.ttl)"
    echo "  Delete it to regenerate"
fi

echo ""

# Step 2: Start triple store
echo "======================================================================"
echo "Step 2: Starting Triple Store ($TRIPLE_STORE)"
echo "======================================================================"
echo ""

case $TRIPLE_STORE in
    fuseki)
        echo "Starting Apache Jena Fuseki..."
        docker-compose -f docker-compose-fuseki.yml up -d
        
        echo "Waiting for Fuseki to start..."
        sleep 15
        
        # Create dataset
        echo "Creating dataset..."
        curl -X POST http://localhost:3030/$/datasets \
          --user admin:rdaccelerate2024 \
          -H "Content-Type: application/x-www-form-urlencoded" \
          --data "dbName=rdaccelerate&dbType=tdb2" \
          -s -o /dev/null || true
        
        echo "✓ Fuseki started"
        echo "  UI: http://localhost:3030"
        echo "  SPARQL: http://localhost:3030/rdaccelerate/sparql"
        ;;
        
    virtuoso)
        echo "Starting Virtuoso..."
        docker-compose -f docker-compose-virtuoso.yml up -d
        
        echo "Waiting for Virtuoso to start..."
        sleep 30
        
        echo "✓ Virtuoso started"
        echo "  UI: http://localhost:8890/conductor"
        echo "  SPARQL: http://localhost:8890/sparql"
        ;;
        
    *)
        echo "✗ Unknown triple store: $TRIPLE_STORE"
        echo "  Supported: fuseki, virtuoso"
        exit 1
        ;;
esac

echo ""

# Step 3: Load RDF data
echo "======================================================================"
echo "Step 3: Loading RDF Data"
echo "======================================================================"
echo ""

case $TRIPLE_STORE in
    fuseki)
        echo "Loading data into Fuseki..."
        
        # Split file if too large (Fuseki has upload limits)
        FILE_SIZE=$(stat -f%z rdaccelerate_kg.ttl 2>/dev/null || stat -c%s rdaccelerate_kg.ttl)
        
        if [ $FILE_SIZE -gt 100000000 ]; then
            echo "File is large (>100MB), using N-Triples format..."
            
            curl -X POST http://localhost:3030/rdaccelerate/data \
              --user admin:rdaccelerate2024 \
              --data-binary @rdaccelerate_kg.nt \
              -H "Content-Type: application/n-triples" \
              -w "\nHTTP Status: %{http_code}\n"
        else
            curl -X POST http://localhost:3030/rdaccelerate/data \
              --user admin:rdaccelerate2024 \
              --data-binary @rdaccelerate_kg.ttl \
              -H "Content-Type: text/turtle" \
              -w "\nHTTP Status: %{http_code}\n"
        fi
        
        echo "✓ Data loaded into Fuseki"
        ;;
        
    virtuoso)
        echo "Loading data into Virtuoso..."
        
        # Copy file to container
        docker cp rdaccelerate_kg.ttl rdaccelerate-virtuoso:/staging/
        
        # Load via ISQL
        docker exec rdaccelerate-virtuoso isql 1111 dba rdaccelerate2024 << 'EOF'
SPARQL CLEAR GRAPH <http://rdaccelerate.org/knowledge-graph>;
DB.DBA.TTLP_MT(file_to_string_output('/staging/rdaccelerate_kg.ttl'), '', 'http://rdaccelerate.org/knowledge-graph');
checkpoint;
EOF
        
        echo "✓ Data loaded into Virtuoso"
        ;;
esac

echo ""

# Step 4: Verify
echo "======================================================================"
echo "Step 4: Verification"
echo "======================================================================"
echo ""

case $TRIPLE_STORE in
    fuseki)
        echo "Counting triples..."
        curl -X POST http://localhost:3030/rdaccelerate/sparql \
          --user admin:rdaccelerate2024 \
          --data-urlencode "query=SELECT (COUNT(*) AS ?count) WHERE { ?s ?p ?o }" \
          -H "Accept: text/csv" 2>/dev/null | tail -n 1
        
        echo ""
        echo "Sample query (first 5 diseases):"
        curl -X POST http://localhost:3030/rdaccelerate/sparql \
          --user admin:rdaccelerate2024 \
          --data-urlencode "query=PREFIX biolink: <https://w3id.org/biolink/vocab/> PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#> SELECT ?disease WHERE { ?disease a biolink:Disease ; rdfs:label ?name } LIMIT 5" \
          -H "Accept: text/csv" 2>/dev/null
        ;;
        
    virtuoso)
        echo "Counting triples..."
        curl -X POST http://localhost:8890/sparql \
          --data-urlencode "query=SELECT (COUNT(*) AS ?count) WHERE { ?s ?p ?o }" \
          --data-urlencode "default-graph-uri=http://rdaccelerate.org/knowledge-graph" \
          -H "Accept: text/csv" 2>/dev/null | tail -n 1
        
        echo ""
        echo "Sample query (first 5 diseases):"
        curl -X POST http://localhost:8890/sparql \
          --data-urlencode "query=PREFIX biolink: <https://w3id.org/biolink/vocab/> PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#> SELECT ?disease WHERE { ?disease a biolink:Disease ; rdfs:label ?name } LIMIT 5" \
          --data-urlencode "default-graph-uri=http://rdaccelerate.org/knowledge-graph" \
          -H "Accept: text/csv" 2>/dev/null
        ;;
esac

echo ""
echo "======================================================================"
echo "✅ CONVERSION COMPLETE!"
echo "======================================================================"
echo ""
echo "Your knowledge graph is now available as RDF/SPARQL!"
echo ""

case $TRIPLE_STORE in
    fuseki)
        cat << 'FUSEKI_INFO'
Apache Jena Fuseki:
  Web UI:        http://localhost:3030
  SPARQL Query:  http://localhost:3030/rdaccelerate/sparql
  SPARQL Update: http://localhost:3030/rdaccelerate/update
  
  Credentials: admin / rdaccelerate2024

Example SPARQL query:
  curl -X POST http://localhost:3030/rdaccelerate/sparql \
    --user admin:rdaccelerate2024 \
    --data-urlencode "query=PREFIX biolink: <https://w3id.org/biolink/vocab/> SELECT * WHERE { ?s a biolink:Disease } LIMIT 10"

FUSEKI_INFO
        ;;
        
    virtuoso)
        cat << 'VIRTUOSO_INFO'
Virtuoso:
  Web UI:        http://localhost:8890/conductor
  SPARQL Query:  http://localhost:8890/sparql
  
  Credentials: dba / rdaccelerate2024
  Graph URI:   http://rdaccelerate.org/knowledge-graph

Example SPARQL query:
  curl -X POST http://localhost:8890/sparql \
    --data-urlencode "query=PREFIX biolink: <https://w3id.org/biolink/vocab/> SELECT * WHERE { ?s a biolink:Disease } LIMIT 10" \
    --data-urlencode "default-graph-uri=http://rdaccelerate.org/knowledge-graph"

VIRTUOSO_INFO
        ;;
esac

echo ""
echo "Next steps:"
echo "  1. Test queries via web UI"
echo "  2. Register with FRINK OKN"
echo "  3. Deploy to public server"
echo ""
