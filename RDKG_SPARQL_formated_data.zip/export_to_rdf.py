#!/usr/bin/env python3
"""
Convert RDAccelerate Neo4j Knowledge Graph to RDF (Turtle format)
For integration with FRINK Open Knowledge Network
"""

from neo4j import GraphDatabase
from rdflib import Graph, Namespace, Literal, URIRef, RDF, RDFS
from rdflib.namespace import XSD, OWL, SKOS
import sys
from tqdm import tqdm

# Configuration
NEO4J_URI = "bolt://localhost:7687"
NEO4J_USER = "neo4j"
NEO4J_PASSWORD = "rdaccelerate2024"

# Define namespaces
BIOLINK = Namespace("https://w3id.org/biolink/vocab/")
RDACCEL = Namespace("https://rdaccelerate.org/resource/")
ORPHANET = Namespace("http://www.orpha.net/ORDO/Orphanet_")
MONDO = Namespace("http://purl.obolibrary.org/obo/MONDO_")
HP = Namespace("http://purl.obolibrary.org/obo/HP_")
NCBI_GENE = Namespace("http://identifiers.org/ncbigene/")
DRUGBANK = Namespace("http://identifiers.org/drugbank/")
CLINVAR = Namespace("http://www.ncbi.nlm.nih.gov/clinvar/variation/")

# Create RDF graph
g = Graph()

# Bind prefixes
g.bind("biolink", BIOLINK)
g.bind("rdaccel", RDACCEL)
g.bind("ordo", ORPHANET)
g.bind("mondo", MONDO)
g.bind("hp", HP)
g.bind("ncbigene", NCBI_GENE)
g.bind("drugbank", DRUGBANK)
g.bind("clinvar", CLINVAR)
g.bind("rdfs", RDFS)
g.bind("owl", OWL)
g.bind("skos", SKOS)

def create_uri(node_id):
    """Convert node ID to proper URI"""
    if node_id.startswith("ORDO:"):
        return ORPHANET[node_id.replace("ORDO:", "")]
    elif node_id.startswith("MONDO:"):
        return MONDO[node_id.replace("MONDO:", "").replace("_", "")]
    elif node_id.startswith("HP:"):
        return HP[node_id.replace("HP:", "")]
    elif node_id.startswith("NCBIGene:"):
        return NCBI_GENE[node_id.replace("NCBIGene:", "")]
    elif node_id.startswith("DrugBank:"):
        return DRUGBANK[node_id.replace("DrugBank:", "")]
    elif node_id.startswith("ClinVar:"):
        return CLINVAR[node_id.replace("ClinVar:", "")]
    else:
        # Generic resource
        return RDACCEL[node_id.replace(":", "_")]

def get_biolink_class(category):
    """Map Biolink category to class URI"""
    if not category:
        return BIOLINK.NamedThing
    
    class_name = category.replace("biolink:", "")
    return BIOLINK[class_name]

def export_nodes(driver, batch_size=1000):
    """Export all nodes as RDF triples"""
    print("Exporting nodes...")
    
    with driver.session() as session:
        # Get total count
        result = session.run("MATCH (n) RETURN count(n) AS total")
        total = result.single()["total"]
        
        print(f"Total nodes: {total:,}")
        
        # Export in batches
        for skip in tqdm(range(0, total, batch_size), desc="Nodes"):
            result = session.run("""
                MATCH (n)
                RETURN n.id AS id, 
                       n.name AS name, 
                       n.category AS category,
                       labels(n)[0] AS label
                ORDER BY id(n)
                SKIP $skip LIMIT $limit
            """, skip=skip, limit=batch_size)
            
            for record in result:
                node_id = record["id"]
                name = record["name"]
                category = record["category"]
                label = record["label"]
                
                if not node_id:
                    continue
                
                # Create URI
                uri = create_uri(node_id)
                
                # Add type
                biolink_class = get_biolink_class(category)
                g.add((uri, RDF.type, biolink_class))
                
                # Add label
                if name:
                    g.add((uri, RDFS.label, Literal(name)))
                    g.add((uri, SKOS.prefLabel, Literal(name)))
                
                # Add ID as literal
                g.add((uri, BIOLINK.id, Literal(node_id)))
                
                # Add category
                if category:
                    g.add((uri, BIOLINK.category, Literal(category)))

def export_relationships(driver, batch_size=1000):
    """Export all relationships as RDF triples"""
    print("\nExporting relationships...")
    
    with driver.session() as session:
        # Get total count
        result = session.run("MATCH ()-[r]->() RETURN count(r) AS total")
        total = result.single()["total"]
        
        print(f"Total relationships: {total:,}")
        
        # Export in batches
        for skip in tqdm(range(0, total, batch_size), desc="Edges"):
            result = session.run("""
                MATCH (s)-[r]->(o)
                RETURN s.id AS subject_id,
                       o.id AS object_id,
                       type(r) AS rel_type,
                       r.predicate AS predicate
                ORDER BY id(r)
                SKIP $skip LIMIT $limit
            """, skip=skip, limit=batch_size)
            
            for record in result:
                subject_id = record["subject_id"]
                object_id = record["object_id"]
                rel_type = record["rel_type"]
                predicate = record["predicate"]
                
                if not subject_id or not object_id:
                    continue
                
                # Create URIs
                subject_uri = create_uri(subject_id)
                object_uri = create_uri(object_id)
                
                # Use Biolink predicate if available, otherwise use rel_type
                if predicate and predicate.startswith("biolink:"):
                    predicate_name = predicate.replace("biolink:", "")
                    predicate_uri = BIOLINK[predicate_name]
                else:
                    # Convert rel_type to snake_case for Biolink
                    predicate_name = rel_type.lower().replace("_", "_")
                    predicate_uri = BIOLINK[predicate_name]
                
                # Add triple
                g.add((subject_uri, predicate_uri, object_uri))

def add_ontology_metadata():
    """Add metadata about the knowledge graph"""
    print("\nAdding ontology metadata...")
    
    # Define the ontology
    kg_uri = RDACCEL["knowledge-graph"]
    
    g.add((kg_uri, RDF.type, OWL.Ontology))
    g.add((kg_uri, RDFS.label, Literal("RDAccelerate Rare Disease Knowledge Graph")))
    g.add((kg_uri, RDFS.comment, Literal(
        "A comprehensive rare disease knowledge graph integrating Orphanet, MONDO, HPO, ClinVar, and DrugBank data"
    )))
    g.add((kg_uri, OWL.versionInfo, Literal("1.0.0")))
    
    # Add property definitions
    properties = [
        ("has_phenotype", "Relates a disease to its associated phenotypes"),
        ("treats", "Relates a drug to the disease it treats"),
        ("gene_associated_with_condition", "Relates a gene to a disease condition"),
        ("causes_condition", "Relates a variant to the disease it causes"),
        ("has_gene", "Relates a variant to its gene"),
        ("subclass_of", "Indicates hierarchical relationship between diseases"),
        ("related_to", "General association between entities")
    ]
    
    for prop_name, description in properties:
        prop_uri = BIOLINK[prop_name]
        g.add((prop_uri, RDF.type, OWL.ObjectProperty))
        g.add((prop_uri, RDFS.label, Literal(prop_name.replace("_", " ").title())))
        g.add((prop_uri, RDFS.comment, Literal(description)))

def main():
    """Main export function"""
    print("=" * 70)
    print("RDAccelerate Knowledge Graph → RDF Converter")
    print("For FRINK Open Knowledge Network Integration")
    print("=" * 70)
    
    # Connect to Neo4j
    print("\nConnecting to Neo4j...")
    driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))
    
    try:
        # Test connection
        with driver.session() as session:
            result = session.run("RETURN 1")
            result.single()
        print("✓ Connected to Neo4j")
        
        # Export nodes
        export_nodes(driver)
        
        # Export relationships
        export_relationships(driver)
        
        # Add metadata
        add_ontology_metadata()
        
        # Save to file
        print("\nSerializing to Turtle format...")
        output_file = "rdaccelerate_kg.ttl"
        g.serialize(destination=output_file, format='turtle')
        
        # Also save as N-Triples (easier to parse)
        nt_file = "rdaccelerate_kg.nt"
        g.serialize(destination=nt_file, format='nt')
        
        print(f"\n✓ RDF export complete!")
        print(f"  Triples: {len(g):,}")
        print(f"  Turtle: {output_file}")
        print(f"  N-Triples: {nt_file}")
        
        # Print sample triples
        print("\n" + "=" * 70)
        print("Sample triples (first 10):")
        print("=" * 70)
        for i, (s, p, o) in enumerate(g):
            if i >= 10:
                break
            print(f"{s} {p} {o}")
        
    finally:
        driver.close()

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n✗ Error: {e}", file=sys.stderr)
        sys.exit(1)
